//
//  CoreCompany+CoreDataProperties.m
//  NavCtrl
//
//  Created by Robert Baghai on 10/29/15.
//  Copyright © 2015 Aditya Narayan. All rights reserved.
//
//  Choose "Create NSManagedObject Subclass…" from the Core Data editor menu
//  to delete and recreate this implementation file for your updated model.
//

#import "CoreCompany+CoreDataProperties.h"

@implementation CoreCompany (CoreDataProperties)

@dynamic companyName;
@dynamic stockCode;
@dynamic companyLogo;
@dynamic prod;

@end
