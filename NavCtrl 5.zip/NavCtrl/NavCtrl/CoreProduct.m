//
//  CoreProduct.m
//  NavCtrl
//
//  Created by Robert Baghai on 10/29/15.
//  Copyright © 2015 Aditya Narayan. All rights reserved.
//

#import "CoreProduct.h"
#import "CoreCompany.h"

@implementation CoreProduct

// Insert code here to add functionality to your managed object subclass

@end
