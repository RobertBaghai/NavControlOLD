//
//  addViewController.m
//  NavCtrl
//
//  Created by Robert Baghai on 10/8/15.
//  Copyright © 2015 Aditya Narayan. All rights reserved.
//

#import "addViewController.h"

@interface addViewController ()

@end

@implementation addViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    _dao = [DataAccessObject sharedInstance];
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/


- (IBAction)submitInfo:(id)sender {

    NSString *compName = self.textName.text;
    NSString *compLogo = @"defaultCLogo.png";
    NSString *compStock = self.textStockCode.text;
   
    Company *comp = [[Company alloc] init];
    comp.companyName = compName;
    comp.companyLogo = compLogo;
    
    if([self.textStockCode.text isEqualToString:@""]){
        comp.stockCode = @"N/A";
    }else{
    comp.stockCode = compStock;
    }
    
    comp.products = [[NSMutableArray alloc]init];
    int position = [self.dao fetchPosition];
    NSLog(@"%d",position);
    comp->c_position = position;
    [self.companyList addObject:comp];
    [self.dao addData:[NSString stringWithFormat:
                       @"INSERT INTO Company (c_name,c_logo,c_stockCode,c_position) VALUES ('%s','%s','%s',%d)",
                       [comp.companyName UTF8String],[comp.companyLogo UTF8String], [comp.stockCode UTF8String],comp->c_position]];
    
    [self.navigationController popViewControllerAnimated:YES];

}

- (void)dealloc {
    [_textTitle release];
    [_textName release];
    [_textStockCode release];
    [super dealloc];
}

@end
